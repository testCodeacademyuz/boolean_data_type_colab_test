from setuptools import setup

setup(
   name='boolean_data_type',
   version='0.1.0',
   packages=['boolean_data_type'],
   description='This is Boolean data type Test',
   install_requires=[
       "requests",
   ]
)